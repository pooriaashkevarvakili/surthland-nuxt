<template>
  <div>
    <div
      class="
        grid
        gap-3
        mt-5
        2xl:ml-5
        xl:ml-5
        lg:ml-5
        ml-6
        md:ml-48
        2xl:grid-cols-3
        xl:grid-cols-3
        lg:grid-cols-2
        md:grid-cols-1
        grid-cols-1
      "
    >
      <div
        class="card 2xl:w-64 xl:w-64 lg:w-64 md:w-80 w-80 bg-base-100 shadow-xl"
      >
        <div class="card-body bg-gray-300">
          <h2 class="card-title">job title</h2>
        </div>
        <div class="card-body">
          <h2 class="card-title">job title</h2>
        </div>
      </div>
      <div
        class="card 2xl:w-64 xl:w-64 lg:w-64 md:w-80 w-80 bg-base-100 shadow-xl"
      >
        <div class="card-body bg-gray-300">
          <h2 class="card-title">job title</h2>
        </div>
        <div class="card-body">
          <h2 class="card-title">job title</h2>
        </div>
      </div>
      <div
        class="card 2xl:w-64 xl:w-64 lg:w-64 md:w-80 w-80 bg-base-100 shadow-xl"
      >
        <div class="card-body bg-gray-300">
          <h2 class="card-title">job title</h2>
        </div>
        <div class="card-body">
          <h2 class="card-title">job title</h2>
        </div>
      </div>
    </div>
    <div
      class="
        grid
        gap-3
        mt-5
        2xl:ml-5
        xl:ml-5
        lg:ml-5
        ml-6
        md:ml-48
        2xl:grid-cols-3
        xl:grid-cols-3
        lg:grid-cols-2
        md:grid-cols-1
        grid-cols-1
      "
    >
      <div
        class="card 2xl:w-64 xl:w-64 lg:w-64 md:w-80 w-80 bg-base-100 shadow-xl"
      >
        <div class="card-body bg-gray-300">
          <h2 class="card-title">job title</h2>
        </div>
        <div class="card-body">
          <h2 class="card-title">job title</h2>
        </div>
      </div>
      <div
        class="card 2xl:w-64 xl:w-64 lg:w-64 md:w-80 w-80 bg-base-100 shadow-xl"
      >
        <div class="card-body bg-gray-300">
          <h2 class="card-title">job title</h2>
        </div>
        <div class="card-body">
          <h2 class="card-title">job title</h2>
        </div>
      </div>
      <div
        class="card 2xl:w-64 xl:w-64 lg:w-64 md:w-80 w-80 bg-base-100 shadow-xl"
      >
        <div class="card-body bg-gray-300">
          <h2 class="card-title">job title</h2>
        </div>
        <div class="card-body">
          <h2 class="card-title">job title</h2>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {};
</script>

<style>
</style>