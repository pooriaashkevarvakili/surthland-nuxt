<template>
  <div></div>
</template>

<script>
export default {
  layout: "forgotpassword",
};
</script>

<style>
</style>