<template>
  <div class="bg-gray-400 h-screen">
    <div class="ml-10 mt-5 py-6 w-10/12 rounded-xl bg-white">
      <div class="ml-5">Messages</div>
      <hr class="mt-3" />
      <div class="ml-5 mt-5">
        In publishing and graphic design, Lorem ipsum is a placeholder text
        commonly used to demonstrate the visual form of a document or a typeface
        without relying on meaningful content. Lorem ipsum may be used as a
        placeholder before final copy is available.
      </div>
      <div class="flex justify-end space-x-3 mr-6">
        <button class="btn btn-outline btn-primary">Apply</button>
        <button class="btn btn-outline btn-primary">delete</button>
      </div>
    </div>
    <div class="ml-10 mt-5 py-6 w-10/12 rounded-xl bg-white">
      <div class="ml-5">Messages</div>
      <hr class="mt-3" />
      <div class="ml-5 mt-5">
        In publishing and graphic design, Lorem ipsum is a placeholder text
        commonly used to demonstrate the visual form of a document or a typeface
        without relying on meaningful content. Lorem ipsum may be used as a
        placeholder before final copy is available.
      </div>
      <div class="flex justify-end space-x-3 mr-6">
        <button class="btn btn-outline btn-primary">Apply</button>
        <button class="btn btn-outline btn-primary">delete</button>
      </div>
    </div>
  </div>
</template>

<script>
export default {};
</script>

<style>
</style>