<template>
  <div></div>
</template>

<script>
export default {
  layout: "signup",
};
</script>
