<template></template>

<script>
export default {
  layout: "signup",
};
</script>

<style>
</style>