const signup = {
    namespaced: true,
    state: () => ({
        usersSignUp: []
    }),
    getters: {
        usersSignUp: state => state.usersSignUp
    },
    mutations: {
        users_Sign_Up(state, usersSignUp) {
            state.usersSignUp = usersSignUp
        }
    },
    actions: {
        getUsers() {
            this.$axios.post('api/auth/register', {
                phone: '',
                password: '',
                email: '',
                password_confirmation: '',
                errors: [],
                error: ''
            }).then(res => {
                res.data
                console.log(res.data.phone);
                console.log(res.data.password);
                console.log(res.data.email);
                console.log(res.data.password_confirmation);
                console.log(res.data.errors);
                console.log(res.data.error);
                commit('users_Sign_Up')
            }).catch(error => {
                alert(error)
                console.log(error)
            })
        }

    }

}
export default signup