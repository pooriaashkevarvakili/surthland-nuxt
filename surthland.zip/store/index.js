import Vue from 'vue'
import Vuex from 'vuex'
import education from "./modules/education"
import experience from "./modules/experience"
import skills from "./modules/skills"
import signup from "./modules/signup"
import login from "./modules/login"
Vue.use(Vuex)
export const state = () => ({

})
export const getters = {

}
export const mutations = {




}
export const actions = {





}
export const modules = {
    education,
    experience,
    skills,
    signup,
    login
}