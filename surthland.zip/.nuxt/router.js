import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _34b68394 = () => interopDefault(import('..\\pages\\AppTabs.vue' /* webpackChunkName: "pages/AppTabs" */))
const _bd3d8500 = () => interopDefault(import('..\\pages\\AppTabsOne.vue' /* webpackChunkName: "pages/AppTabsOne" */))
const _8c6e2334 = () => interopDefault(import('..\\pages\\AppTabsTwo.vue' /* webpackChunkName: "pages/AppTabsTwo" */))
const _511ca45f = () => interopDefault(import('..\\pages\\Education.vue' /* webpackChunkName: "pages/Education" */))
const _6dab6cc3 = () => interopDefault(import('..\\pages\\Experience.vue' /* webpackChunkName: "pages/Experience" */))
const _f4fa38d2 = () => interopDefault(import('..\\pages\\forgotPassword.vue' /* webpackChunkName: "pages/forgotPassword" */))
const _66484e74 = () => interopDefault(import('..\\pages\\header.vue' /* webpackChunkName: "pages/header" */))
const _44028658 = () => interopDefault(import('..\\pages\\home.vue' /* webpackChunkName: "pages/home" */))
const _01c4da4f = () => interopDefault(import('..\\pages\\jobs.vue' /* webpackChunkName: "pages/jobs" */))
const _c3f20272 = () => interopDefault(import('..\\pages\\jobsOne.vue' /* webpackChunkName: "pages/jobsOne" */))
const _5a332b40 = () => interopDefault(import('..\\pages\\login.vue' /* webpackChunkName: "pages/login" */))
const _ea406036 = () => interopDefault(import('..\\pages\\Messages.vue' /* webpackChunkName: "pages/Messages" */))
const _35c8ee66 = () => interopDefault(import('..\\pages\\resume.vue' /* webpackChunkName: "pages/resume" */))
const _388c29d1 = () => interopDefault(import('..\\pages\\signup.vue' /* webpackChunkName: "pages/signup" */))
const _2eab701b = () => interopDefault(import('..\\pages\\Skills.vue' /* webpackChunkName: "pages/Skills" */))
const _d84c54ca = () => interopDefault(import('..\\pages\\skillsOne.vue' /* webpackChunkName: "pages/skillsOne" */))
const _dee8efae = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages/index" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/AppTabs",
    component: _34b68394,
    name: "AppTabs"
  }, {
    path: "/AppTabsOne",
    component: _bd3d8500,
    name: "AppTabsOne"
  }, {
    path: "/AppTabsTwo",
    component: _8c6e2334,
    name: "AppTabsTwo"
  }, {
    path: "/Education",
    component: _511ca45f,
    name: "Education"
  }, {
    path: "/Experience",
    component: _6dab6cc3,
    name: "Experience"
  }, {
    path: "/forgotPassword",
    component: _f4fa38d2,
    name: "forgotPassword"
  }, {
    path: "/header",
    component: _66484e74,
    name: "header"
  }, {
    path: "/home",
    component: _44028658,
    name: "home"
  }, {
    path: "/jobs",
    component: _01c4da4f,
    name: "jobs"
  }, {
    path: "/jobsOne",
    component: _c3f20272,
    name: "jobsOne"
  }, {
    path: "/login",
    component: _5a332b40,
    name: "login"
  }, {
    path: "/Messages",
    component: _ea406036,
    name: "Messages"
  }, {
    path: "/resume",
    component: _35c8ee66,
    name: "resume"
  }, {
    path: "/signup",
    component: _388c29d1,
    name: "signup"
  }, {
    path: "/Skills",
    component: _2eab701b,
    name: "Skills"
  }, {
    path: "/skillsOne",
    component: _d84c54ca,
    name: "skillsOne"
  }, {
    path: "/",
    component: _dee8efae,
    name: "index"
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
